some more information about statistic config

[CommonAttrType]
ITEM_STAT means xxx_val is reference from [playeritemstat.txt].group_id
TASK_STAT means xxx_val is reference from [playertaskstat.txt].group_id
ROLE_BASE means xxx_val is predefined base attr of player, see [RoleBaseAttrDef]
ITEM_GROUP means xxx_val is reference from [itemgroup.txt].group_id
ITEM_BASE means xxx_val is an item base attribute, see [ItemBaseAttrDef]
CONST means xxx_val is a const number value

[RoleBaseAttrDef]
0 = none
1 = LEVEL
2 = FACTION_PATH
3 = FACTION
4 = GOLD_ALL
5 = TRANS_LEVEL
9 = OFFLINE_DAYS
10 = LASTLOGIN_DAYS_PAST
11 = EXP
12 = REBORN_COUNT	
13 = REBORN_ROUTE	


[ItemBaseAttrDef]
0 = none
1001 = ITEM_G
1002 = ITEM_D
1003 = ITEM_P
1004 = ITEM_ENHANCE
1005 = ITEM_NUM
1006 = ITEM_PLACE	;values see [ItemPlaceDef]
1007 = ITEM_CUR_LINGQI
1008 = ITEM_MAX_LINGQI

[ItemPlaceDef]
1 = CurEquip
2 = Bag
3 = StoreBox
7 = SelfStall

[StatType]
COUNT
SUM
AVG

[PreTreatmentType]
NONE
ABS
BYTE1
BYTE2
BYTE3
BYTE4
WORD1
WORD2

[TaskStatType]
TASK means xxx_val is a task_id
GROUP means xxx_val is another task group_id

[OffLineDaysLimit]
-1 means config is not a valid config
0 means config is limit without offline time
>0 means offline time limit only less than this days

[LineID]
it is only a sign to each config, it never used in statistic
