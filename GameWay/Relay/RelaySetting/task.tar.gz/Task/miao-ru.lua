Include("\\RelaySetting\\Task\\GoldBossHead.lua");
Sid = 513
Interval = 30;
Count = 0;
StartHour=-1;
StartMin=-1;

function NewBoss()
	return 1, 20, 513, random(80,90);
end;



