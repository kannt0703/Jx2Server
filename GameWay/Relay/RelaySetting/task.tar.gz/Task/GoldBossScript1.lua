Include("\\RelaySetting\\Task\\GoldBossHead.lua");
Sid = 1
Interval = 10;
Count = 0;
StartHour=-1;
StartMin=-1;

function NewBoss()
	return 1, 20, 140, 50;
end;



