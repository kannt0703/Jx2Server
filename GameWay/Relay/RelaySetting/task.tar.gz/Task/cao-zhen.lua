Include("\\RelaySetting\\Task\\GoldBossHead.lua");
Sid = 517
Interval = 30;
Count = 0;
StartHour=-1;
StartMin=-1;

function NewBoss()
	return 1, 20, 517, random(80,88);
end;



