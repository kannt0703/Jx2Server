Include("\\RelaySetting\\Task\\GoldBossHead.lua");
Sid = 523
Interval = 30;
Count = 0;
StartHour=-1;
StartMin=-1;

function NewBoss()
	return 1, 20, 523, random(70,80);
end;



