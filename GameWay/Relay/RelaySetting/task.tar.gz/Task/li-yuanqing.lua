Include("\\RelaySetting\\Task\\GoldBossHead.lua");
Sid = 514
Interval = 30;
Count = 0;
StartHour=-1;
StartMin=-1;

function NewBoss()
	return 1, 20, 514, random(80,90);
end;



