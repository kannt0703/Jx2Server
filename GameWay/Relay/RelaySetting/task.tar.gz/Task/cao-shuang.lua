Include("\\RelaySetting\\Task\\GoldBossHead.lua");
Sid = 518
Interval = 30;
Count = 0;
StartHour=-1;
StartMin=-1;

function NewBoss()
	return 1, 20, 518, random(80,85);
end;



